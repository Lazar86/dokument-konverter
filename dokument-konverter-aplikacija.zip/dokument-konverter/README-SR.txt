DOKUMENT KONVERTER — UPUTSTVO

ŠTA RADI
- Prima fotografije JPG/PNG/WEBP i PDF dokumente.
- Izvlači tekst iz PDF-a koji sadrži pravi tekst.
- OCR prepoznaje tekst sa fotografija i skeniranih PDF stranica.
- Omogućava ručnu ispravku pre izvoza u DOCX, XLSX ili TXT.
- Radi u pregledaču; biblioteke se učitavaju sa interneta.

VAŽNO
Ovo je početna verzija (MVP), nije zamena za profesionalni OCR. Rukopis, pečati, loš kvalitet slike i složene tabele mogu biti pogrešno prepoznati. Izvoz u Excel stavlja svaki red prepoznatog teksta u zaseban red; ne rekonstruiše automatski složene kolone. Potrebna je internet veza za učitavanje OCR i export biblioteka. PWA instalacija zahteva HTTPS hosting (npr. GitHub Pages).

NAJLAKŠE POSTAVLJANJE NA INTERNET
1. Na računaru otvori https://github.com/ i napravi besplatan nalog ako ga nemaš.
2. Klikni + pa New repository. Naziv: dokument-konverter. Izaberi Public, zatim Create repository.
3. U repozitorijumu izaberi Add file > Upload files.
4. Raspakuj ZIP i prevuci SVE fajlove iz ovog foldera (index.html, manifest.webmanifest, sw.js, icon.svg, README-SR.txt) na GitHub stranicu.
5. Klikni Commit changes.
6. Otvori Settings > Pages. U delu Build and deployment izaberi Deploy from a branch; Branch: main, folder: /(root), pa Save.
7. Sačekaj minut-dva. GitHub će prikazati adresu oblika https://TVOJE-IME.github.io/dokument-konverter/ . Otvori je i probaj aplikaciju.

INSTALACIJA NA iPHONE
1. Otvori objavljenu HTTPS adresu u Safari-ju (ne unutar aplikacije GitHub).
2. Pritisni Share (kvadrat sa strelicom nagore).
3. Izaberi Add to Home Screen / Dodaj na početni ekran. Ako ne vidiš opciju, skroluj meni nadole.
4. Pritisni Add / Dodaj. Ikonica će se pojaviti na početnom ekranu.

INSTALACIJA NA RAČUNAR
- Otvori istu adresu u Chrome ili Edge.
- Klikni ikonicu instalacije u adresnoj traci, ako se pojavi, ili otvori meni pregledača i izaberi Install app / Instaliraj aplikaciju.

KORIŠĆENJE
1. Izaberi fotografije ili PDF.
2. Klikni Prepoznaj / izdvoji tekst.
3. Sačekaj obradu. Kod skeniranog PDF-a obrađuje se stranica po stranica.
4. Ispravi tekst u velikom polju.
5. Klikni Word, Excel ili TXT.

PRIVATNOST
OCR se izvršava u pregledaču, ali se potrebne programske biblioteke i jezički modeli preuzimaju sa spoljašnjih servisa. Nemoj obrađivati poverljive ili osetljive dokumente ako pravila tvoje organizacije to ne dozvoljavaju. Za korišćenje je potrebna internet veza.
